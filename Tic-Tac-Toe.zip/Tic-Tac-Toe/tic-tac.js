window.onload = function() {
	var min;
	var max;
	if( window.innerHeight < window.innerWidth)
	{
		min = window.innerHeight;
		max = window.innerWidth;
	}
	else
	{
		min = window.innerWidth;
		max = window.innerHeight;
	}
	var type;
	var main = document.getElementById("main");
	if(max == window.innerHeight)
	{	
		max = (max-min)/2;
		main.style.marginTop = max.toString()+'px';
		main.style.marginBottom = max.toString()+'px';
	}
	else
	{	
		max = (max-min)/2;
		main.style.marginLeft = max.toString()+'px';
		main.style.marginRight = max.toString()+'px';
	}
	main.style.height = min.toString()+'px';
	main.style.width = min.toString()+'px';
	for( j=0; j<3; j++)
	{
		var block1 = document.createElement('span');
		block1.setAttribute("class", 'block');
		block1.style.width = ((min/3)-10).toString()+'px';
		block1.style.height = ((min/3)-2.5).toString()+'px';
		block1.setAttribute("onclick", 'xo(this)');
		block1.style.marginLeft = '0px';
		block1.style.marginRight = '5px';
		block1.setAttribute("state", 0);
		main.appendChild(block1);
		var block2 = document.createElement('span');
		block2.setAttribute("class", 'block');
		block2.style.width = ((min/3)-5).toString()+'px';
		block2.style.height = ((min/3)-2.5).toString()+'px';
		block2.style.marginLeft = '5px';
		block1.style.marginRight = '5px';
		block2.setAttribute("onclick", 'xo(this)');
		block2.setAttribute("state", 0);
		main.appendChild(block2);
		block3 = document.createElement('span');
		block3.setAttribute("class", 'block');
		block3.style.width = ((min/3)-5).toString()+'px';
		block3.style.height = ((min/3)-2.5).toString()+'px';
		block3.style.marginLeft = '10px';
		block3.style.marginRight = '0px';
		block3.setAttribute("onclick", 'xo(this)');
		block3.setAttribute("state", 0);
		main.appendChild(block3);
	}
}
var list = document.getElementsByClassName('block')

function check() {
	if( list[0].getAttribute('state') == 1 && list[1].getAttribute('state') == 1 && list[2].getAttribute('state') == 1 ) {
		if( list[0].getAttribute('player') == list[1].getAttribute('player') == list[2].getAttribute('player') )
		{
			alert("player "+(list[0].getAttribute('player'))+' wins!');
			location.reload();
		}
	}
	if( list[4].getAttribute('state') == 1 && list[5].getAttribute('state') == 1 && list[3].getAttribute('state') == 1 ) {
		if( list[4].getAttribute('player') == list[5].getAttribute('player') == list[3].getAttribute('player') )
		{
			alert("player "+(list[4].getAttribute('player'))+' wins!');
			location.reload();
		}
	}
	if( list[7].getAttribute('state') == 1 && list[8].getAttribute('state') == 1 && list[6].getAttribute('state') == 1 ) {
		if( list[7].getAttribute('player') == list[8].getAttribute('player') == list[6].getAttribute('player') )
		{
			alert("player "+(list[7].getAttribute('player'))+' wins!');
			location.reload();
		}
	}
	if( list[0].getAttribute('state') == 1 && list[3].getAttribute('state') == 1 && list[6].getAttribute('state') == 1 ) {
		if( list[0].getAttribute('player') == list[3].getAttribute('player') == list[6].getAttribute('player') )
		{
			alert("player "+(list[0].getAttribute('player'))+' wins!');
			location.reload();
		}
	}
	if( list[1].getAttribute('state') == 1 && list[4].getAttribute('state') == 1 && list[7].getAttribute('state') == 1 ) {
		if( (list[1].getAttribute('player') == list[4].getAttribute('player')) && (list[7].getAttribute('player') == list[4].getAttribute('player')))
		{
			alert("player "+(list[7].getAttribute('player'))+' wins!');
			location.reload();
		}
	}
	if( list[2].getAttribute('state') == 1 && list[5].getAttribute('state') == 1 && list[8].getAttribute('state') == 1 ) {
		if( list[2].getAttribute('player') == list[5].getAttribute('player') == list[8].getAttribute('player') )
		{
			alert("player "+(list[2].getAttribute('player'))+' wins!');
			location.reload();
		}
	}
	if( list[0].getAttribute('state') == 1 && list[4].getAttribute('state') == 1 && list[8].getAttribute('state') == 1 ) {
		if( list[0].getAttribute('player') == list[4].getAttribute('player') == list[8].getAttribute('player') )
		{
			alert("player "+(list[0].getAttribute('player'))+' wins!');
			location.reload();
		}
	}
	if( list[2].getAttribute('state') == 1 && list[4].getAttribute('state') == 1 && list[6].getAttribute('state') == 1 ) {
		if( list[2].getAttribute('player') == list[4].getAttribute('player') == list[6].getAttribute('player') )
		{
			alert("player "+(list[2].getAttribute('player'))+' wins!');
			location.reload();
		}
	}
	var flag = 0;
	for( i=0; i<9; i++)
	{
		if( list[i].getAttribute('state') == 0 )
			flag = 1;
	}
	if( flag == 0 )
	{
		alert("It's a Draw!");
		location.reload();
	}
}
var player = 1;
function xo(abcd) {
	if( abcd.getAttribute('state') == 0 )
	{
		if( player == 1 )
		{
			player = 2;
			abcd.setAttribute("player", 1);
			var image = document.createElement('img');
			image.setAttribute("src", "x.jpg");
			image.style.width = abcd.style.width;
			image.style.height = abcd.style.height;
			image.style.marginLeft = abcd.style.marginLeft;
			image.style.marginRight = abcd.style.marginRight;

			abcd.appendChild(image);
		}
		else if(player == 2)
		{
			player = 1;
			abcd.setAttribute("player", 2);
			var image = document.createElement('img');
			image.setAttribute("src", "o.jpg");
			image.style.width = abcd.style.width;
			image.style.height = abcd.style.height;
			image.style.marginRight = abcd.style.marginRight;

			abcd.appendChild(image);
		}
		abcd.setAttribute('state', 1);
	}
	check();
}